#!/usr/bin/env python3
import sys
import re
import os
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.tree import Tree
from rich.markdown import Markdown

# 挂载 src 目录以导入核心模块
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from engine import WagstaffEngine
from analyzer import LuaAnalyzer, LootParser, PrefabParser

console = Console()

class WagstaffWiki:
    def __init__(self):
        try:
            self.engine = WagstaffEngine(load_db=True)
            # console.print(f"[dim]Wiki 引擎已连接 (文件数: {len(self.engine.file_list)})[/dim]")
        except Exception as e:
            console.print(f"[red]引擎初始化失败: {e}[/red]")
            sys.exit(1)

    def run(self, args):
        if not args:
            self._print_help()
            return

        command = args[0].lower()
        query = args[1] if len(args) > 1 else None

        if command == "recipe":
            self._search_recipe(query)
        elif command == "mob" or command == "item":
            self._analyze_prefab(query)
        elif command == "loot":
            self._find_loot_table(query)
        elif command == "find":
            self._global_search(query)
        else:
            self._print_help()

    def _print_help(self):
        console.print(Panel("""
[bold cyan]📖 Wagstaff Wiki v2.0[/bold cyan]

[green]bin/wagstaff wiki recipe <物品名>[/green]   查询配方 (支持模糊匹配)
[green]bin/wagstaff wiki mob <生物名>[/green]      查询生物/物品详情 (属性、组件)
[green]bin/wagstaff wiki loot <表名>[/green]       [bold yellow]🔥 查询掉落表/掉落率[/bold yellow]
[green]bin/wagstaff wiki find <关键词>[/green]     全局代码搜索
""", title="Help", border_style="blue"))

    def _search_recipe(self, query):
        if not query: return console.print("[red]请输入物品名称[/red]")
        
        real_name, recipe_data = self.engine.recipes.get(query)
        
        if not recipe_data:
            # 模糊搜索
            candidates = [k for k in self.engine.recipes.recipes.keys() if query in k]
            if not candidates:
                return console.print(f"[red]未找到配方: {query}[/red]")
            if len(candidates) > 1:
                console.print(f"[yellow]可能的匹配: {', '.join(candidates[:5])}...[/yellow]")
                return
            real_name, recipe_data = self.engine.recipes.get(candidates[0])

        grid = Table.grid(expand=True)
        grid.add_column()
        grid.add_column(justify="right")
        
        # 标题行
        tab_info = recipe_data.get('tab', 'UNKNOWN').replace("RECIPETABS.", "")
        grid.add_row(f"[bold gold1]{real_name.upper()}[/bold gold1]", f"[dim]{tab_info}[/dim]")
        
        # 科技需求
        tech = recipe_data.get('tech', 'UNKNOWN').replace("TECH.", "")
        grid.add_row(f"[bold]科技:[/bold] {tech}", "")
        
        # 材料列表
        grid.add_row("\n[bold]所需材料:[/bold]")
        for ing in recipe_data.get('ingredients', []):
            grid.add_row(f"  • [cyan]{ing['item']}[/cyan]", f"[yellow]x{ing['amount']}[/yellow]")
            
        console.print(Panel(grid, title="🛠️  配方详情", border_style="gold1"))

    def _analyze_prefab(self, query):
        """分析 Prefab 组件结构 (增强版: 显示属性与数值)"""
        if not query: return console.print("[red]请输入名称[/red]")
        
        filepath = self.engine.find_file(query, fuzzy=True)
        if not filepath:
            return console.print(f"[red]未找到文件: {query}[/red]")

        content = self.engine.read_file(filepath)
        report = LuaAnalyzer(content).get_report()
        
        tree = Tree(f"🧬 [bold green]实体情报: {os.path.basename(filepath)}[/bold green]")
        
        # 使用 Tuning 增强数值显示
        tuning = self.engine.tuning

        if report.get('components'):
            comp_branch = tree.add("⚙️ 关键组件")
            for comp in report['components']:
                c_name = comp['name']
                # 只有当组件有内容时才展开，或者是核心组件
                has_content = comp.get('properties') or comp.get('methods')
                
                style = "bold yellow"
                # 高亮核心数值组件
                if c_name in ['weapon', 'health', 'hunger', 'sanity', 'armor', 'lootdropper']:
                    style = "bold magenta"
                
                node_text = f"[{style}]{c_name}[/{style}]"
                
                if not has_content:
                    comp_branch.add(node_text)
                    continue
                
                comp_node = comp_branch.add(node_text)
                
                # 1. 显示属性
                for prop in comp.get('properties', []):
                    val_text = tuning.enrich(prop) if tuning else prop
                    comp_node.add(f"[dim]•[/dim] {val_text}")

                # 2. 显示方法
                for method in comp.get('methods', []):
                    val_text = tuning.enrich(method) if tuning else method
                    
                    # 关键方法高亮
                    if any(k in method for k in ["SetDamage", "SetMaxHealth", "SetArmor"]):
                        comp_node.add(f"[bold green]ƒ {val_text}[/bold green]")
                    elif "SetChanceLootTable" in method or "SetSharedLootTable" in method:
                        comp_node.add(f"[bold red]ƒ {val_text}[/bold red]")
                    else:
                        comp_node.add(f"[dim]ƒ[/dim] {val_text}")

        console.print(Panel(tree, border_style="green"))
        console.print(f"\n💡 提示: 若发现 [red]SetChanceLootTable('NAME')[/red]，\n请运行: [bold cyan]bin/wagstaff wiki loot NAME[/bold cyan] 查看掉落率")

    def _find_loot_table(self, query):
        """
        全库扫描 + LootParser 强力解析
        """
        if not query: return console.print("[red]请输入掉落表名称 (例如: krampus)[/red]")
        
        console.print(f"[dim]正在全库搜索掉落表: '{query}' ...[/dim]")
        
        # 特征码: SetSharedLootTable('NAME'
        pattern = re.compile(r'SetSharedLootTable\s*\(\s*[\'"]' + re.escape(query) + r'[\'"]')
        
        found = False
        for filepath in self.engine.file_list:
            if not filepath.endswith(".lua"): continue
            
            content = self.engine.read_file(filepath)
            if not content: continue
            
            if pattern.search(content):
                self._render_loot_table(filepath, query, content)
                found = True
                break 
        
        if not found:
            console.print(f"[red]未找到掉落表定义: '{query}'[/red]")
            console.print("[dim]提示：有些掉落是代码动态生成的，或者表名与实体名不一致。[/dim]")

    def _render_loot_table(self, filepath, table_name, content):
        console.print(f"[bold green]✅ 找到定义文件: {filepath}[/bold green]")
        
        # 强制使用 LootParser 解析该文件
        parser = LootParser(content)
        data = parser.parse()
        
        if not data['entries']:
            console.print("[yellow]解析器未能提取到具体物品项 (可能是复杂的动态逻辑)。[/yellow]")
            return

        table = Table(title=f"💰 掉落表: {table_name}", box=None)
        table.add_column("物品 (Prefab)", style="cyan")
        table.add_column("几率 / 权重", style="magenta")
        table.add_column("类型", style="dim")

        for entry in data['entries']:
            val_str = ""
            if 'chance' in entry:
                # 格式化百分比
                pct = entry['chance'] * 100
                if pct < 1: val_str = f"{pct:.2f}%"
                else: val_str = f"{pct:.0f}%"
            elif 'weight' in entry:
                val_str = f"权重 {entry['weight']}"
            
            table.add_row(entry['item'], val_str, entry['method'])

        console.print(Panel(table, border_style="gold1"))

    def _global_search(self, query):
        if not query: return
        count = 0
        console.print(f"[dim]搜索 '{query}'...[/dim]")
        for f in self.engine.file_list:
            content = self.engine.read_file(f)
            if content and query in content:
                console.print(f"📄 {f}")
                count += 1
                if count >= 10:
                    console.print("[dim]...结果过多，仅显示前 10 个[/dim]")
                    break

if __name__ == "__main__":
    WagstaffWiki().run(sys.argv[1:])